package com.cst438.domain;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="user_table")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String alias;
	private String firstName;
	private String lastName;
	private String email; 	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="user")
	private List<Attempt> attempts;


//     <Getter and Setter methods and no-arg constructor are not shown> 
	public void setAlias(String al) {
		this.alias = al;
	}
	


}