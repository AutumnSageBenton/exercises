package com.cst438.domain;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Attempt {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private int factorA;
	private int factorB;
	private int attempt;
	private int answer;
	private boolean isCorrect;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="user_id")
	private User user;


//<Getter and Setter methods and no-arg constructor are not shown>
	public void setAnswer(int ans) {
		this.answer = ans;
	}
	public void setAttempt(int atpm) {
		this.attempt = atpm;
	}
	public void setCorrect(boolean cor) {
		this.isCorrect = cor;
	} 
	public void setFactorA(int fact) {
		this.factorA = fact;
	}
	public void setFactorB(int fact) {
		this.factorB = fact;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public int getId() {
		return this.id;
	}
	public int getFactorA() {
		return this.factorA;
	}
	public int getFactorB() {
		return this.factorB;
	}
	public int getAttempt() {
		return this.attempt;
	}
	public int getAnswer() {
		return this.answer;
	}
	public boolean isCorrect() {
		return this.isCorrect;
	}

}