package com.cst438.dto;

public record MultiplyProblem (String alias, int factorA, int factorB, int attempt) {
};

