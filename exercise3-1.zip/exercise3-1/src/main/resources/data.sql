insert into user_table 
( alias, first_name, last_name, email) 
values
( 'dw', 'david', 'wisneski', 'dwisneski@csumb.edu');

