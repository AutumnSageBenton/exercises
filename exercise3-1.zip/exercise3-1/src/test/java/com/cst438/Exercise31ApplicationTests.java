package com.cst438;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercise31ApplicationTests {

	@Test
	void contextLoads() {
	}

}
